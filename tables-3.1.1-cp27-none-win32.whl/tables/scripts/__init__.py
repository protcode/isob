# -*- coding: utf-8 -*-

########################################################################
#
# License: BSD
# Created: 2005-12-01
# Author:  Ivan Vilata i Balaguer - ivan@selidor.net
#
# $Id$
#
########################################################################

"""Utility scripts for PyTables.

This package contains some modules which provide a ``main()`` function
(with no arguments), so that they can be used as scripts.

"""
